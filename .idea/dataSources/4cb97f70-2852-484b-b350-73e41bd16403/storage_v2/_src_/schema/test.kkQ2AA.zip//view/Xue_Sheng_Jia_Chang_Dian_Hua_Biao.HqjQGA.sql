create view 学生家长电话表 as
  select `test`.`s_family`.`s_no`       AS `s_no`,
         `test`.`s_family`.`g_phone`    AS `g_phone`,
         `test`.`s_family`.`s_relation` AS `s_relation`
  from `test`.`s_family`;

