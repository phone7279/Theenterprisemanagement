create view 挂科表 as
  select `test`.`s_grade`.`s_no` AS `s_no`, `test`.`s_grade`.`c_name` AS `c_name`, `test`.`s_grade`.`grade` AS `grade`
  from `test`.`s_grade`
  where (`test`.`s_grade`.`grade` < 60);

