create view 学生电话 as
  select `test`.`s_information`.`s_no` AS `s_no`, `test`.`s_information`.`s_phone` AS `s_phone`
  from `test`.`s_information`;

