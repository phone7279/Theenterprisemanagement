create view 班级教师表 as
  select `test`.`c_information`.`class`   AS `class`,
         `test`.`c_information`.`i_name`  AS `i_name`,
         `test`.`c_information`.`i_phone` AS `i_phone`
  from `test`.`c_information`;

