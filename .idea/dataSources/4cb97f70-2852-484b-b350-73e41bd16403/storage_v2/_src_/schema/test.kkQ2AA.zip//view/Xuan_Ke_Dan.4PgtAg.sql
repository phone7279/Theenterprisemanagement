create view 选课单 as
  select `test`.`s_family`.`s_no`    AS `s_no`,
         `test`.`s_family`.`g_phone` AS `g_phone`,
         `test`.`s_family`.`g_name`  AS `g_name`
  from `test`.`s_family`;

