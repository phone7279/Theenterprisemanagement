create view 总成绩表 as
  select `test`.`s_grade`.`s_no`   AS `s_no`,
         `test`.`s_grade`.`s_name` AS `s_name`,
         `test`.`s_grade`.`grade`  AS `sum_grade`
  from `test`.`s_grade`
  group by `test`.`s_grade`.`id`;

