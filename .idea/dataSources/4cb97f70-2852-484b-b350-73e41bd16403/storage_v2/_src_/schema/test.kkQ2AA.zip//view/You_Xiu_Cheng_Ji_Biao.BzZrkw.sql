create view 优秀成绩表 as
  select `test`.`s_grade`.`grade`  AS `grade`,
         `test`.`s_grade`.`c_name` AS `c_name`,
         `test`.`s_grade`.`s_name` AS `s_name`
  from `test`.`s_grade`
  where (`test`.`s_grade`.`grade` >= 90);

